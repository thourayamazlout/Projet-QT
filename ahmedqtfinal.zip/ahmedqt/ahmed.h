#ifndef AHMED_H
#define AHMED_H

#include <QMainWindow>
#include "employe.h"
#include "veterinaire.h"
#include "smtp.h"
#include <QtCharts>
#include <QChartView>
#include <QLineSeries>



QT_BEGIN_NAMESPACE
namespace Ui { class Ahmed; }
QT_END_NAMESPACE

class Ahmed : public QMainWindow
{
    Q_OBJECT

public:
    Ahmed(QWidget *parent = nullptr);
    ~Ahmed();

private slots:

    void on_pb_ajouter_veterinaire_clicked();

    void on_pb_ajouter_employe_clicked();

    void on_pb_supprimer_employe_clicked();

    void on_pb_modifier_employe_clicked();

    void on_pb_supprimer_veterinaire_clicked();

    void on_pb_modifier_veterinaire_clicked();

    void on_pb_pushbutton_tri_clicked();

    void on_pb_pushbutton_pdf_clicked();

    void on_pb_pushbutton_tri1_clicked();

    void on_pb_confirmer_clicked();

    void on_pushbutton_rechercher1_clicked();

    void on_pushbutton_rechercher_clicked();

    void sendMail();

    void mailSent(QString);

    void on_pushbutton_stat_clicked();

private:
     Ui::Ahmed *ui;
     Veterinaire *tmpveterinaire;
     Employe *tmpemploye;
};
#endif // MAINWINDOW_H

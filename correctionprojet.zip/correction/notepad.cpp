#include "notepad.h"

Notepad::Notepad()
{

}

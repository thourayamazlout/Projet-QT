#include "ui_materiel.h"
#include "materiel.h"
#include<QDate>
#include<QMessageBox>
#include<QSystemTrayIcon>
#include<QDateEdit>
Materiel::Materiel()
{
    id=0;
    type="";
    etat="";
    dateachat= QDate();
    maint="";
}
Materiel::Materiel(int id,QString type,QString etat,QDate dateachat,QString maint)
{
    this->id=id;
     this->type=type;
     this->etat=etat;
    this->dateachat=dateachat;
    this->maint=maint;
}
QString Materiel::get_type(){return type;}
QString Materiel::get_etat(){return etat;}
QDate Materiel::get_dateachat(){return dateachat;}
QString Materiel::get_maint(){return maint;}
int Materiel::get_id(){return id;}


Materiel::Materiel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Materiel)
{
    ui->setupUi(this);
}

Materiel::~Materiel()
{
    delete ui;
}

void Materiel::on_pushButton_clicked()
{
    m = new Maintenance(this);
    m-> show();
}

bool Materiel::ajouter()
{   QSqlQuery query;
    QString res=QString::number(id);
    query.prepare("INSERT INTO MATERIEL (ID,TYPE,ETAT,DATEACHAT,MAINT)""VALUES(:id,:type,:etat,:dateachat,:maint)");
    query.bindValue(":id",res);
    query.bindValue(":type",type);
    query.bindValue(":etat",etat);
    query.bindValue(":dateachat",dateachat);
    query.bindValue(":maint",maint);
 return query.exec();
}
bool Materiel::supprimer(int id)
{
QSqlQuery query;
QString res= QString::number(id);
query.prepare("Delete from MATERIEL where ID = :id ");
query.bindValue(":id", res);
return    query.exec();
}

bool Materiel::modifier()
{   QSqlQuery query;
    QString res=QString::number(id);
    query.prepare( "UPDATE MATERIEL SET ID=:mm.id, TYPE=:mm.type,ETAT=:mm.etat,DATEACHAT=:mm.dateachat,MAINT=:mm.maint WHERE ID=:mm.id");
    query.bindValue(":mm.id",res);
    query.bindValue(":mm.type",type);
    query.bindValue(":mm.etat",etat);
    query.bindValue(":mm.dateachat",dateachat);
    query.bindValue(":mm.maint",maint);
 return query.exec();
}

QSqlQueryModel * Materiel::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from materiel");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("ETAT"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("DATEACHAT"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("MAINT"));
    return model;
}


void Materiel::on_pushButton_ajouter_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    QString type = ui->lineEdit_type->text();
    QString etat = ui->lineEdit_etat->text();
    QDate dateachat = ui->dateEdit_achat->date();
    QString maint = ui->lineEdit_maint->text();
    Materiel mat (id,type,etat,dateachat,maint);

    notifier = new QSystemTrayIcon(this);
    //notifier = new QSystemTrayIcon(this);
        notifier->setIcon(QIcon(":/notification.png"));
        notifier->show();

  if (ui->lineEdit_id->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP IDENTIFIANT!!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
          else if (ui->lineEdit_type->text().isEmpty())
           {

               QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP type!!!!") ;
               QMessageBox::critical(0, qApp->tr("Ajout"),

                               qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

           }
  else if (ui->lineEdit_etat->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP etat !!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else if (ui->dateEdit_achat->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP date !!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else if (ui->lineEdit_maint->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP maintenance entrez (oui) ou (non) !!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else {
      bool test=mat.ajouter();
    if (test)
    {   ui->tabmateriel->setModel(tmpmateriel->afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Ajouter un materiel"),
                          QObject::tr("materiel ajouté.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);}


    else

        notifier->showMessage("Ok","materiel ajoute",QSystemTrayIcon::Warning,10000);}

 ui->lineEdit_id->setText("");
 ui->lineEdit_etat->setText("");
 ui->lineEdit_type->setText("");
 ui->dateEdit_achat-> date();
 ui->lineEdit_maint->setText("");
}
void Materiel::on_pushButton_supprimer_clicked()
{
    int id = ui->lineEdit_id_2->text().toInt();
    bool test=tmpmateriel->supprimer(id);
    if(test)
    {ui->tabmateriel->setModel(tmpmateriel->afficher());
        QString str = " Vous voulez vraiment supprimer \n le produit ayant pour identifiant :"+ ui->lineEdit_id1->text();
                      int ret = QMessageBox::question(this, tr("Produit"),str,QMessageBox::Ok|QMessageBox::Cancel);

                      switch (ret) {
                        case QMessageBox::Ok:
                            if (tmpmateriel->supprimer(id))
                                QMessageBox ::information(0, qApp->tr("Suppression"),
                                                          qApp->tr("le produit a été supprimé"), QMessageBox::Ok);


                          break;
                        case QMessageBox::Cancel:

                            break;
                        default:
                            // should never be reached
                            break;
                      }}
    else
              {

                  QMessageBox::critical(0, qApp->tr("Suppression"),
                      qApp->tr("produit non trouvé ou en maintenance "), QMessageBox::Cancel);

              }

}









void Materiel::on_pushButton_modifier_clicked()
{

        QString id = ui->lineEdit_id1->text();
        QString type = ui->lineEdit_type1->text();
        QString etat = ui->lineEdit_etat1->text();
        QDate dateachat = ui->lineEdit_achat1->date();
        QString maint = ui->lineEdit_maint1->text();
        QSqlQuery query;
        query.prepare("UPDATE MATERIEL SET ID =:id,TYPE = :type,ETAT = :etat,DATEACHAT=:dateachat, MAINT=:maint where ID = :id");
        query.bindValue(":id",id);
        query.bindValue(":type",type);
        query.bindValue(":etat",etat);
        query.bindValue(":dateachat",dateachat);
        query.bindValue(":maint",maint);
        bool test = query.exec();
        if(test)
        {

            ui->tabmateriel->setModel(tmpmateriel->afficher());//refresh
            QMessageBox::information(nullptr, QObject::tr("Modifier abonné"),
                        QObject::tr("véhicule Modifier.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

        }
        else
        {
            QMessageBox::critical(nullptr, QObject::tr("Supprimer abonné"),
                        QObject::tr("Erreur !.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);
        }

        ui->lineEdit_id1->clear();
        ui->lineEdit_type1->clear();
        ui->lineEdit_etat1->clear();
        ui->lineEdit_achat1->clear();
        ui->lineEdit_maint1->clear();


}

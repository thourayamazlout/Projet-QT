#include "maintenance.h"
#include "ui_maintenance.h"
#include<QDate>
#include<QMessageBox>
#include<QSystemTrayIcon>
Maintenance::Maintenance()
{
    id_mat=0;
    type_pan="";
    agent_maint="";
    date_prise_en_charge=QDate();
    note="";
}
Maintenance::Maintenance(int id_mat,QString type_pan,QString note,QString agent_maint,QDate date_prise_en_charge)
{
    this->id_mat=id_mat;
    this->type_pan=type_pan;
    this->note=note;
    this->agent_maint=agent_maint;
    this->date_prise_en_charge=date_prise_en_charge;

}
int Maintenance::get_id_mat(){return id_mat;}
QString Maintenance::get_type_pan(){return type_pan;}
QString Maintenance::get_note(){return note;}
QString Maintenance::get_agent_maint(){return agent_maint;}
QDate Maintenance::get_date_prise_en_charge(){return date_prise_en_charge;}

Maintenance::Maintenance(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Maintenance)
{
    ui->setupUi(this);
}

Maintenance::~Maintenance()
{
    delete ui;
}
bool Maintenance::ajouter()
{   QSqlQuery query;
    QString res=QString::number(id_mat);
    query.prepare("INSERT INTO MAINTENANCE(ID_MAT,TYPEPAN,NOTE,AGENTMAINT,DPRISEENCHARGE)""VALUES(:id_mat,:type_pan,:note,:agent_maint,:date_prise_en_charge)");
    query.bindValue(":id_mat",res);
    query.bindValue(":type_pan",type_pan);
    query.bindValue(":note",note);
    query.bindValue(":agent_maint",agent_maint);
    query.bindValue(":date_prise_en_charge",date_prise_en_charge);

 return query.exec();
}
bool Maintenance::supprimer(int id_mat)
{
QSqlQuery query;
QString res= QString::number(id_mat);
query.prepare("DELETE FROM MAINTENANCE WHERE ID_MAT = :id_mat");
query.bindValue(":id_mat", res);
return    query.exec();
}

bool Maintenance::modifier()
{   QSqlQuery query;
    QString res=QString::number(id_mat);
    query.prepare( "UPDATE MAINTENANCE SET ID_MAT=:id_mat,TYPEPAN=:type_pan,AGENTMAINT=:agent_maint,DPRISEENCHARGE=:date_prise_en_charge,NOTE=:note WHERE ID_MAT=:id_mat");
    query.bindValue(":id_mat",res);
    query.bindValue(":type_pan",type_pan);
    query.bindValue(":agent_maint",agent_maint);
    query.bindValue(":date_prise_en_charge",date_prise_en_charge);
    query.bindValue(":note",note);
 return query.exec();
}

QSqlQueryModel * Maintenance::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("SELECT * FROM MAINTENANCE");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_MAT"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPEPAN "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("NOTE"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("AGENTMAINT"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("DPRISEENCHARGE"));

    return model;
}

void Maintenance::on_pushButton_ajouter_clicked()
{
    int id_mat = ui->lineEdit_id->text().toInt();
    QString type_pan = ui->lineEdit_pan->text();
    QString note = ui->lineEdit_note->text();
    QString agent_maint = ui->lineEdit_agentmaint->text();
    QDate date_prise_en_charge = ui->dateEdit_date->date();
    Maintenance maint (id_mat,type_pan,note,agent_maint,date_prise_en_charge);

    notifier = new QSystemTrayIcon(this);

        notifier->show();

  if (ui->lineEdit_id->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP IDENTIFIANT!!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
          else if (ui->lineEdit_pan->text().isEmpty())
           {

               QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP type de panne !!!!") ;
               QMessageBox::critical(0, qApp->tr("Ajout"),

                               qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

           }
  else if (ui->lineEdit_note->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP note !!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else if (ui->dateEdit_date->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP date de prise en charge!!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else if (ui->lineEdit_agentmaint->text().isEmpty())
   {

       QMessageBox::information(this," ERREUR "," VEUILLEZ VERIFIER CHAMP agent de maintenance  !!!!") ;
       QMessageBox::critical(0, qApp->tr("Ajout"),

                       qApp->tr("Probleme d'ajout"), QMessageBox::Cancel);

   }
  else {
      bool test=maint.ajouter();
    if (test)
    {   ui->tableView->setModel(tmpmaint->afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Ajouter un materiel"),
                          QObject::tr("materiel a maintenir ajouté.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);}


    else

        notifier->showMessage("Ok","materiel a maintenir ajoute",QSystemTrayIcon::Warning,10000);}


    }


void Maintenance::on_pushButton_modifier_clicked()
{
        int id_mat = ui->lineEdit_10->text().toInt();
        QString type_pan = ui->lineEdit_7->text();
        QString note = ui->lineEdit_9->text();
        QString agent_maint = ui->lineEdit_6->text();
        QDate date_prise_en_charge = ui->dateEdit->date();
    QSqlQuery query;
    query.prepare( "UPDATE MAINTENANCE SET ID_MAT=:id_mat,TYPEPAN=:type_pan,AGENTMAINT=:agent_maint,DPRISEENCHARGE=:date_prise_en_charge,NOTE=:note WHERE ID_MAT=:id_mat");
    query.bindValue(":id_mat",id_mat);
    query.bindValue(":type_pan",type_pan);
    query.bindValue(":agent_maint",agent_maint);
    query.bindValue(":date_prise_en_charge",date_prise_en_charge);
    query.bindValue(":note",note);
    bool test = query.exec();
    if(test)
    {

        ui->tableView->setModel(tmpmaint->afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Modifierle materiel a maintenir"),
                    QObject::tr("materiel Modifié.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


    }
    else
    {
        QMessageBox::critical(nullptr, QObject::tr("Supprimer materiel"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    }

    ui->lineEdit_id->clear();
    ui->lineEdit_pan->clear();
    ui->lineEdit_note->clear();
    ui->lineEdit_agentmaint->clear();
    ui->dateEdit_date->clear();


}

void Maintenance::on_pushButton_supprimer_clicked()
{
    int id_mat = ui->lineEdit_11->text().toInt();

    bool test=tmpmaint->supprimer(id_mat);
    if(test)
    {   ui->tableView->setModel(tmpmaint->afficher());
        QString str = " Vous voulez vraiment supprimer \n le produit ayant pour identifiant :"+ ui->lineEdit_id->text();
                      int ret = QMessageBox::question(this, tr("materiel"),str,QMessageBox::Ok|QMessageBox::Cancel);

                      switch (ret) {
                        case QMessageBox::Ok:
                            if (tmpmaint->supprimer(id_mat))
                                QMessageBox ::information(0, qApp->tr("Suppression"),
                                                          qApp->tr("le produit a été supprimé"), QMessageBox::Ok);


                          break;
                        case QMessageBox::Cancel:

                            break;
                        default:
                            // should never be reached
                            break;
                      }}
    else
              {

                  QMessageBox::critical(0, qApp->tr("Suppression"),
                      qApp->tr("materiel inexistant "), QMessageBox::Cancel);

              }
}

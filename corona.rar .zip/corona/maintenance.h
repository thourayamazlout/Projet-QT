#ifndef MAINTENANCE_H
#define MAINTENANCE_H
#include<QSqlQueryModel>
#include<QSqlQuery>
#include<QDate>
#include <QDialog>
#include<QSystemTrayIcon>
namespace Ui {
class Maintenance;
}

class Maintenance : public QDialog
{
    Q_OBJECT
    QString type_pan,agent_maint,note;
    int id_mat;
    QDate date_prise_en_charge;
public:
    explicit Maintenance(QWidget *parent = nullptr);
    ~Maintenance();
    Maintenance();
    Maintenance(int,QString,QString,QString ,QDate);
    int get_id_mat();
    QString get_type_pan();
    QString get_agent_maint();
    QString get_note();
    QDate get_date_prise_en_charge();
    bool ajouter();
    bool modifier();
    QSqlQueryModel *afficher();
    bool supprimer(int);
private slots:



    void on_pushButton_ajouter_clicked();

    void on_pushButton_modifier_clicked();

    void on_pushButton_supprimer_clicked();

private:
    Ui::Maintenance *ui;
    Maintenance *tmpmaint;
    QSystemTrayIcon *notifier;
};

#endif // MAINTENANCE_H

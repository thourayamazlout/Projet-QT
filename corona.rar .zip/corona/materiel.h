#ifndef MATERIEL_H
#define MATERIEL_H
#include "maintenance.h"
#include <QDialog>
#include<QSqlQueryModel>
#include<QSqlQuery>
#include<QDate>
#include<QSystemTrayIcon>
namespace Ui {
class Materiel;
}

class Materiel : public QDialog
{
    Q_OBJECT
    QString type,etat,maint;
    int id;
    QDate dateachat;

public:
    explicit Materiel(QWidget *parent = nullptr);
    Materiel();
    Materiel (int,QString,QString,QDate,QString);
    int get_id();
    QString get_type();
    QString get_etat();
    QString get_maint();
    QDate get_dateachat();
    bool ajouter();
    bool modifier();
    QSqlQueryModel *afficher();
    bool supprimer(int);
    ~Materiel();


private slots:
    void on_pushButton_clicked();



    void on_pushButton_ajouter_clicked();



    void on_pushButton_supprimer_clicked();





    void on_pushButton_modifier_clicked();

private:
    Ui::Materiel *ui;
    Maintenance *m;
    Materiel *tmpmateriel;
    QSystemTrayIcon *notifier;

};

#endif // MATERIEL_H

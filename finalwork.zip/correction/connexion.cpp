#include "connexion.h"
#include <qsqldatabase.h>
Connexion::Connexion()
{

}
bool Connexion::connecter()
{
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("source_projet2A");
db.setUserName("thouraya");
db.setPassword("root");
if(db.open())
return true;
return false;

}

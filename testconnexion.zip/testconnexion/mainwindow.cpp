#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"etudiant.h"
#include <QMessageBox>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_ajouter_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    QString nom = ui->lineEdit_nom->text();
    QString prenom = ui->lineEdit_prenom->text();
    Etudiant e (id,nom,prenom);
    bool test=e.ajouter();
    if (test)
    {ui->tabetudiant->setModel(tmpetudiant.afficher());//refresh
        QMessageBox::information(nullptr, QObject::tr("Ajouter un étudiant"),
                          QObject::tr("Etudiant ajouté.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);}

}


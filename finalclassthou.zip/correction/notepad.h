#ifndef NOTEPAD_H
#define NOTEPAD_H


class Notepad
{
public:
    Notepad();
};

#endif // NOTEPAD_H

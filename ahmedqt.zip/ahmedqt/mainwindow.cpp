#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include "veterinaire.h"
#include "employe.h"
#include "connexion.h"
#include <QPainter>
#include <QPdfWriter>
#include <QDesktopServices>
#include <QUrl>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->tabveterinaire->setModel(tmpveterinaire->afficher());
    ui->tabemploye->setModel(tmpemploye->afficher());

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pb_ajouter_veterinaire_clicked()
{
        QString id = ui->lineEdit_v->text();
        QString nom = ui->lineEdit_nomv->text();
        QString prenom = ui->lineEdit_prenomv->text();
        QString specialite = ui->lineEdit_specialite->text();
        QDate diplome = ui->lineEdit_diplome->date();
        int exp = ui->lineEdit_exp->text().toInt();



        Veterinaire n(id,nom,prenom,specialite,diplome,exp);

      bool test=n.ajouter();
      if(test)
      { ui->tabveterinaire->setModel(tmpveterinaire->afficher());
            ui->comboBox_3->setModel(tmpveterinaire->afficher());
            ui->comboBox_4->setModel(tmpveterinaire->afficher());

          QMessageBox::information(nullptr, QObject::tr("Ajouter veterinaire"),
                            QObject::tr("veterinaire ajouté.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

    }
      else
          QMessageBox::critical(nullptr, QObject::tr("Ajouter veterinaire"),
                      QObject::tr("Erreur !.\n"
                                  "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_ajouter_employe_clicked()
{
    QString id = ui->lineEdit_id_2->text();
    QString nom = ui->lineEdit_nome->text();
    QString prenom = ui->lineEdit_prenome->text();
    QString fonction = ui->lineEdit_fonctione->text();
    int salaire = ui->lineEdit_salairee->text().toInt();
  Employe m(id,nom,prenom,fonction,salaire);
  bool test=m.ajouter();
  if(test)
  { ui->tabemploye ->setModel(tmpemploye->afficher());
       ui->comboBox_11->setModel(tmpemploye->afficher());
       ui->comboBox_12->setModel(tmpemploye->afficher());
      QMessageBox::information(nullptr, QObject::tr("Ajouter employe"),
                        QObject::tr("employe ajouté.\n"
                                    "Click Cancel to exit."), QMessageBox::Cancel);

}
  else
      QMessageBox::critical(nullptr, QObject::tr("Ajouter employe"),
                  QObject::tr("Erreur !.\n"
                              "Click Cancel to exit."), QMessageBox::Cancel);
}

void MainWindow::on_pb_supprimer_employe_clicked()
{
    QString id=ui->comboBox_11->currentText();
    bool test=tmpemploye->supprimer(id);
    if(test)
    {ui->tabemploye->setModel(tmpemploye->afficher());//refresh
        ui->comboBox_11->setModel(tmpveterinaire->afficher());

        QMessageBox::information(nullptr, QObject::tr("Supprimer employe"),
                    QObject::tr("employe supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer employe"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);


}

void MainWindow::on_pb_modifier_employe_clicked()
{
           QString id=ui->comboBox_12->currentText();
           QString nom = ui->lineEdit_nom2e->text();
           QString prenom = ui->lineEdit_prenom2e->text();
           QString fonction = ui->lineEdit_fonction2e->text();
           int salaire = ui->lineEdit_salaire2e->text().toInt();

           Employe emp (id,nom,prenom,fonction,salaire);

                   QSqlQuery query;

                   bool test=emp.modifier();
                   if(test)
                   {

                       ui->tabemploye->setModel(tmpemploye->afficher());//refresh
                       ui->comboBox_12->setModel(tmpemploye->afficher());

                       QMessageBox::information(nullptr, QObject::tr("Modifier employe"),
                                   QObject::tr("employe Modifier.\n"
                                               "Click Cancel to exit."), QMessageBox::Cancel);

                   }
                   else
                   {
                       QMessageBox::critical(nullptr, QObject::tr("Supprimer Medicament"),
                                   QObject::tr("Erreur !.\n"
                                               "Click Cancel to exit."), QMessageBox::Cancel);
                   }

                   ui->lineEdit_nom2e->clear();
                   ui->lineEdit_prenom2e->clear();
                   ui->lineEdit_fonction2e->clear();
                   ui->lineEdit_salaire2e->clear();

}



void MainWindow::on_pb_supprimer_veterinaire_clicked()
{
    QString id=ui->comboBox_3->currentText();
    bool test=tmpveterinaire->supprimer(id);
    if(test)
    {ui->tabveterinaire->setModel(tmpveterinaire->afficher());//refresh
        ui->comboBox_3->setModel(tmpveterinaire->afficher());
        QMessageBox::information(nullptr, QObject::tr("Supprimer veterinaire"),
                    QObject::tr("veterinaire supprimé.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer veterinaire"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}

void MainWindow::on_pb_modifier_veterinaire_clicked()
{
    QString id=ui->comboBox_4->currentText();
    QString nom = ui->lineEdit_nomv2->text();
    QString prenom = ui->lineEdit_prenomv2->text();
    QString specialite = ui->lineEdit_specialitev2->text();
    QDate diplome = ui->lineEdit_diplomev2->date();
    int exp = ui->lineEdit_expv2->text().toInt();



    Veterinaire vet (id,nom,prenom,specialite,diplome,exp);

            QSqlQuery query;

            bool test=vet.modifier();
            if(test)
            {

                ui->tabveterinaire->setModel(tmpveterinaire->afficher());//refresh
                ui->comboBox_4->setModel(tmpveterinaire->afficher());
                QMessageBox::information(nullptr, QObject::tr("Modifier veterinaire"),
                            QObject::tr("veterinaire Modifier.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);

            }
            else
            {
                QMessageBox::critical(nullptr, QObject::tr("Supprimer veterinaire"),
                            QObject::tr("Erreur !.\n"
                                        "Click Cancel to exit."), QMessageBox::Cancel);
            }


            ui->lineEdit_nomv2->clear();
            ui->lineEdit_prenomv2->clear();
            ui->lineEdit_specialitev2->clear();
            ui->lineEdit_diplomev2->clear();
            ui->lineEdit_expv2->clear();

}


 void MainWindow::on_pb_pushbutton_tri_clicked()
 {
     ui->tabveterinaire->setModel(tmpveterinaire->triveterinaire());
 }

 void MainWindow::on_pb_pushbutton_tri1_clicked()
 {
     ui->tabemploye->setModel(tmpemploye->triemploye());
 }

 void MainWindow::on_pb_pushbutton_pdf_clicked(){
     //QDateTime datecreation = date.currentDateTime();
     //QString afficheDC = "Date de Creation PDF : " + datecreation.toString() ;
            QPdfWriter pdf("C:/Users/Ouertani/Downloads/Pdf.pdf");
            QPainter painter(&pdf);
           int i = 4000;
                painter.setPen(Qt::blue);
                painter.setFont(QFont("Arial", 30));
                painter.drawText(1100,1200,"Liste Des Employes");
                painter.setPen(Qt::black);
                painter.setFont(QFont("Arial", 50));
               // painter.drawText(1100,2000,afficheDC);
                painter.drawRect(100,100,7300,2600);
                //painter.drawPixmap(QRect(7600,70,2000,2600),QPixmap("C:/Users/RH/Desktop/projecpp/image/logopdf.png"));
                painter.drawRect(0,3000,9600,500);
                painter.setFont(QFont("Arial", 9));
                painter.drawText(200,3300,"ID");
                painter.drawText(1700,3300,"NOM");
                painter.drawText(3200,3300,"PRENOM");
                painter.drawText(4900,3300,"FONCTION");
                painter.drawText(6600,3300,"SALAIRE");
                QSqlQuery query;
                query.prepare("select * from EMPLOYE");
                query.exec();
                while (query.next())
                {
                    painter.drawText(200,i,query.value(0).toString());
                    painter.drawText(1700,i,query.value(1).toString());
                    painter.drawText(3200,i,query.value(2).toString());
                    painter.drawText(4900,i,query.value(3).toString());
                    painter.drawText(6600,i,query.value(4).toString());
                   i = i + 700;
                }
                int reponse = QMessageBox::question(this, "Génerer PDF", "<PDF Enregistré>...Vous Voulez Affichez Le PDF ?", QMessageBox::Yes |  QMessageBox::No);
                    if (reponse == QMessageBox::Yes)
                    {
                        QDesktopServices::openUrl(QUrl::fromLocalFile("C:/Users/Ouertani/Downloads/Pdf.pdf"));
                        painter.end();
                    }
                    if (reponse == QMessageBox::No)
                    {
                         painter.end();
                    }
 }

void MainWindow::on_pushbutton_rechercher1_clicked()
{

    QString nom = ui->lineEdit_rechercher11->text();
    ui->tabveterinaire->setModel(tmpveterinaire->rechercher1(nom));
}


void MainWindow::on_pushbutton_rechercher_clicked()
{
    QString nom = ui->lineEdit_rechercher->text();
    ui->tabemploye->setModel(tmpemploye->rechercher(nom));
}

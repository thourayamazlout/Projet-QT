#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "employe.h"
#include "veterinaire.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pb_ajouter_veterinaire_clicked();

    void on_pb_ajouter_employe_clicked();

    void on_pb_supprimer_employe_clicked();

    void on_pb_modifier_employe_clicked();

    void on_pb_supprimer_veterinaire_clicked();

    void on_pb_modifier_veterinaire_clicked();

    void on_pb_pushbutton_rechercher_clicked();

    void on_pb_pushbutton_tri_clicked();

    void on_pb_pushbutton_pdf_clicked();

    void on_pb_pushbutton_tri1_clicked();

    void on_pb_pushbutton_rechercher1_clicked();





    void on_pushbutton_rechercher1_clicked();

    void on_pushbutton_rechercher_clicked();

private:
    Ui::MainWindow *ui;
     Veterinaire *tmpveterinaire;
     Employe *tmpemploye;
};
#endif // MAINWINDOW_H

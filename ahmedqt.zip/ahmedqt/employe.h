#ifndef EMPLOYE_H
#define EMPLOYE_H
#include <QString>
#include <QDialog>
#include<QSqlQueryModel>
#include<QSqlQuery>

class Employe
{
public:
    Employe();
    Employe(QString,QString,QString,QString,int);
    QString get_id();
    QString get_nom();
    QString get_prenom();
    QString get_fonction();
    int get_salaire();
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(QString);
    bool modifier();
    QSqlQueryModel * rechercher(QString);
    QSqlQueryModel * triemploye();

private:
    QString nom,prenom,fonction,id;
    int salaire;
};

#endif // EMPLOYE_H

